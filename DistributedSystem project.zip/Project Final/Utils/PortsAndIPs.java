package Utils;

public class PortsAndIPs {

    public static final int Sequencer_PortNum = 3000;

    public static final String RMGroupIPAddress = "230.1.1.10";
    public static final int RM_Group_PortNum = 4000;
    public static final String RM_Feedback_IPAddress = "230.1.1.5";
    public static final int RM_Feedback_Portnum = 5000;
    public static final int RM1_CON_PortNum = 4011;
    public static final int RM1_MCG_PortNum = 4012;
    public static final int RM1_MON_PortNum = 4013;

    public static final int RM2_CON_PortNum = 4021;
    public static final int RM2_MCG_PortNum = 4022;
    public static final int RM2_MON_PortNum = 4023;

    public static final int RM3_CON_PortNum = 4031;
    public static final int RM3_MCG_PortNum = 4032;
    public static final int RM3_MON_PortNum = 4033;

    public static final int RM4_CON_PortNum = 4041;
    public static final int RM4_MCG_PortNum = 4042;
    public static final int RM4_MON_PortNum = 4043;


}
