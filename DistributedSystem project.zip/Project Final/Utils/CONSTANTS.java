package Utils;

public class CONSTANTS {
    public static final int TOTAL_REPLICA = 4;
    public static final int FE_TIME_OUT = 10000;
}
